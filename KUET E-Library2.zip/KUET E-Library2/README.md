# CoreData
This is my code for the tutorial on Core Data
