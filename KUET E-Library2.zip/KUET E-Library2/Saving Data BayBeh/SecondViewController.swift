//
//  SecondViewController.swift
//  Saving Data BayBeh
//
//  Created by Safial Islam on 12/10/17.
//  Copyright © 2017 Kyle Lee. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {


    @IBAction func goToFirst(_ sender: Any) {
        performSegue(withIdentifier: "goToFirst", sender: self)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
