//
//  ViewController.swift
//  Whats The Weather
//
//  Created by Rob Percival on 20/06/2016.
//  Copyright © 2016 Appfish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet var cityTextField: UITextField!
    
    @IBOutlet var resultLabel: UILabel!
    
    @IBOutlet var resultLabel1: UILabel!
    @IBOutlet var resultLabel2: UILabel!
    @IBOutlet var resultLabel3: UILabel!
    @IBOutlet var resultLabel4: UILabel!
    
    @IBAction func getWeather(_ sender: AnyObject) {
        
        if let url = URL(string: "http://library.kuet.ac.bd:8000/cgi-bin/koha/opac-detail.pl?biblionumber=" + cityTextField.text!) {
            
            let request = NSMutableURLRequest(url: url)
            
            let task = URLSession.shared.dataTask(with: request as URLRequest) {
                data, response, error in
                
                var message = ""
                var message1 = ""
                var message2 = ""
                var message3 = ""
                var message4 = ""
                
                if error != nil {
                    
                    print(error)
                    
                } else {
                    
                    if let unwrappedData = data {
                        
                        
                        
                        let dataString = NSString(data: unwrappedData, encoding: String.Encoding.utf8.rawValue)
                        
                        
                        var stringSeparator = "<h1 class=\"title\" property=\"name\">"
                        if let contentArray = dataString?.components(separatedBy: stringSeparator) {
                            
                            if contentArray.count > 1 {
                                
                                stringSeparator = "<span class=\"title_resp_stmt\">"
                                
                                let newContentArray = contentArray[1].components(separatedBy: stringSeparator)
                                
                                if newContentArray.count > 1 {
                                    
                                    message = newContentArray[0].replacingOccurrences(of: "&deg;", with: "°")
                                    
                                    print(message)
                                    
                                    var stringSeparator = "<span class=\"title_resp_stmt\">"
                                    if let contentArray = dataString?.components(separatedBy: stringSeparator) {
                                        
                                        if contentArray.count > 1 {
                                            
                                            stringSeparator = "</span>"
                                            
                                            let newContentArray = contentArray[1].components(separatedBy: stringSeparator)
                                            
                                            if newContentArray.count > 1 {
                                                
                                                message1 = newContentArray[0].replacingOccurrences(of: "&deg;", with: "°")
                                                
                                                print(message1)
                                                
                                                var stringSeparator = "<span property=\"bookEdition\">"
                                                if let contentArray = dataString?.components(separatedBy: stringSeparator) {
                                                    
                                                    if contentArray.count > 1 {
                                                        
                                                        stringSeparator = "</span>"
                                                        
                                                        let newContentArray = contentArray[1].components(separatedBy: stringSeparator)
                                                        
                                                        if newContentArray.count > 1 {
                                                            
                                                            message2 = newContentArray[0].replacingOccurrences(of: "&deg;", with: "°")
                                                            
                                                            print(message2)
                                                            
                                                            var stringSeparator = "<span property=\"isbn\">"
                                                            if let contentArray = dataString?.components(separatedBy: stringSeparator) {
                                                                
                                                                if contentArray.count > 1 {
                                                                    
                                                                    stringSeparator = "</span>"
                                                                    
                                                                    let newContentArray = contentArray[1].components(separatedBy: stringSeparator)
                                                                    
                                                                    if newContentArray.count > 1 {
                                                                        
                                                                        message3 = newContentArray[0].replacingOccurrences(of: "&deg;", with: "°")
                                                                        
                                                                        print(message3)
                                                                        
                                                                        var stringSeparator = "<a href=\"#holdings\">"
                                                                        if let contentArray = dataString?.components(separatedBy: stringSeparator) {
                                                                            
                                                                            if contentArray.count > 1 {
                                                                                
                                                                                stringSeparator = "</a>"
                                                                                
                                                                                let newContentArray = contentArray[1].components(separatedBy: stringSeparator)
                                                                                
                                                                                if newContentArray.count > 1 {
                                                                                    
                                                                                    message4 = newContentArray[0].replacingOccurrences(of: "&deg;", with: "°")
                                                                                    
                                                                                    print(message4)
                                                                                    
                                                                                }
                                                                            }
                                                                        }
                                                                        
                                                                    }
                                                                }
                                                            }
                                                            
                                                        }
                                                    }
                                                }
                                                
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                
                if message == "" {
                    
                    message = "Not Connected to Internet."
                    
                }
                
                if message1 == "" {
                    
                    message1 = "Not Connected to Internet."
                    
                }
                
                if message2 == "" {
                    
                    message2 = "Not Connected to Internet."
                    
                }
                
                if message3 == "" {
                    
                    message3 = "Not Connected to Internet.."
                    
                }
                
                if message4 == "" {
                    
                    message4 = "Not Connected to Internet.."
                    
                }
                
                
                DispatchQueue.main.sync(execute: {
                    
                    self.resultLabel.text = message
                    
                })
                
                DispatchQueue.main.sync(execute: {
                    
                    self.resultLabel1.text = message1
                    
                })
                
                DispatchQueue.main.sync(execute: {
                    
                    self.resultLabel2.text = message2
                    
                })
                
                DispatchQueue.main.sync(execute: {
                    
                    self.resultLabel3.text = message3
                    
                })
                
                DispatchQueue.main.sync(execute: {
                    
                    self.resultLabel4.text = message4
                    
                })
                
            }
            
            task.resume()
            
        } else {
            resultLabel.text  = "Not Connected to Internet."
            resultLabel1.text = "Not Connected to Internet."
            resultLabel2.text = "Not Connected to Internet."
            resultLabel3.text = "Not Connected to Internet."
            resultLabel4.text = "Not Connected to Internet.."
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

